package com.example.Emploee;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmploeeApplicationTests {

	@Test
	void contextLoads() {
	}

}
