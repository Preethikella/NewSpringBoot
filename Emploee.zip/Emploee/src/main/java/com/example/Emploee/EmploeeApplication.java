package com.example.Emploee;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmploeeApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmploeeApplication.class, args);
	}

}
